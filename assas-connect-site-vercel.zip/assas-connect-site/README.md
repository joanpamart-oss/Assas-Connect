# Assas Connect — site prêt pour Vercel

## Lancer en local

```bash
npm install
npm run dev
```

## Construire le site

```bash
npm run build
```

## Déployer sur Vercel

1. Crée un compte ou connecte-toi sur Vercel.
2. Crée un nouveau projet.
3. Importe ce dossier ou un dépôt Git contenant ce dossier.
4. Vercel détectera automatiquement Vite.
5. Clique sur **Deploy**.

## Personnalisation rapide

- Le contenu principal est dans `src/App.jsx`
- Les styles sont dans `src/index.css`
- Le logo est dans `src/assets/logo-assas-connect.jpg`
