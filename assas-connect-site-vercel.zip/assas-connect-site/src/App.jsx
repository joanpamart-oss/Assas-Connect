import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  GraduationCap,
  Mail,
  MapPin,
  Menu,
  Newspaper,
  PenSquare,
  Users,
  X,
} from 'lucide-react'
import logoImage from './assets/logo-assas-connect.jpg'

const brand = {
  name: 'Assas Connect',
  subtitle: 'Association universitaire de Paris II Panthéon-Assas',
  tagline:
    "Un espace pour valoriser nos projets, publier nos articles et rassembler les membres de l'association autour d'initiatives étudiantes ambitieuses.",
  email: 'assasconnect@gmail.com',
  address: 'Paris II Panthéon-Assas · Paris',
}

const navItems = [
  { label: 'Accueil', href: '#accueil' },
  { label: 'Actualités', href: '#actualites' },
  { label: 'Rédaction', href: '#redaction' },
  { label: 'Espace membre', href: '#membres' },
  { label: 'Contact', href: '#contact' },
]

const highlights = [
  "Présenter les projets de l'association",
  'Publier des articles et prises de parole',
  'Mettre en lumière les membres et les pôles',
  'Créer une vitrine claire pour les étudiants et partenaires',
]

const newsItems = [
  {
    title: "Lancement d'un nouveau projet associatif",
    date: 'Avril 2026',
    description:
      "Présente ici un projet porté par l'association : événement, initiative étudiante, partenariat, concours ou programme en préparation.",
  },
  {
    title: 'Retour sur un événement marquant',
    date: 'Mars 2026',
    description:
      "Ajoute un résumé d'une conférence, d'une rencontre ou d'une action menée par l'équipe pour mettre en avant la vie de l'association.",
  },
  {
    title: 'Annonce à venir pour les membres',
    date: 'Bientôt',
    description:
      "Cette carte peut servir à relayer une candidature, une réunion, un appel à contribution ou une nouveauté importante.",
  },
]

const articles = [
  {
    title: 'Tribunes, analyses et articles étudiants',
    category: 'Rédaction',
    description:
      'Cet espace permet de publier des contenus plus approfondis : analyses, éditoriaux, comptes rendus, entretiens ou articles thématiques.',
  },
  {
    title: "Mettre en avant les prises de position de l'association",
    category: 'Publication',
    description:
      'Chaque article peut renvoyer vers une page dédiée avec un texte complet, un auteur, une date et une image de couverture.',
  },
  {
    title: 'Créer une mémoire éditoriale du projet associatif',
    category: 'Archives',
    description:
      'La section rédaction sert aussi à conserver les contenus publiés dans le temps et à valoriser le travail des membres.',
  },
]

const members = [
  { firstName: 'Prénom', lastName: 'Nom', role: 'Présidente' },
  { firstName: 'Prénom', lastName: 'Nom', role: 'Vice-président' },
  { firstName: 'Prénom', lastName: 'Nom', role: 'Secrétaire générale' },
  { firstName: 'Prénom', lastName: 'Nom', role: 'Trésorier' },
  { firstName: 'Prénom', lastName: 'Nom', role: 'Responsable communication' },
  { firstName: 'Prénom', lastName: 'Nom', role: 'Responsable rédaction' },
]

function fadeUp(delay = 0) {
  return {
    initial: { opacity: 0, y: 24 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, amount: 0.25 },
    transition: { duration: 0.5, delay },
  }
}

function SectionTitle({ eyebrow, title, description }) {
  return (
    <div className="section-title">
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      <p className="section-description">{description}</p>
    </div>
  )
}

function PrimaryButton({ href, children }) {
  return (
    <a className="button button-primary" href={href}>
      {children}
    </a>
  )
}

function SecondaryButton({ href, children }) {
  return (
    <a className="button button-secondary" href={href}>
      {children}
    </a>
  )
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="container nav-row">
          <a href="#accueil" className="brand-lockup">
            <img src={logoImage} alt="Logo Assas Connect" className="brand-logo" />
            <div>
              <p className="brand-kicker">Association universitaire</p>
              <p className="brand-name">{brand.name}</p>
            </div>
          </a>

          <nav className="desktop-nav">
            {navItems.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>

          <div className="desktop-cta">
            <PrimaryButton href="#membres">Rejoindre l'association</PrimaryButton>
          </div>

          <button
            type="button"
            className="menu-button"
            onClick={() => setMenuOpen((value) => !value)}
            aria-label="Ouvrir le menu"
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {menuOpen && (
          <div className="mobile-menu">
            <div className="container mobile-menu-inner">
              {navItems.map((item) => (
                <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>
                  {item.label}
                </a>
              ))}
              <PrimaryButton href="#membres">Rejoindre l'association</PrimaryButton>
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="accueil" className="hero-section">
          <div className="hero-background" />
          <div className="container hero-grid">
            <motion.div className="hero-copy" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="hero-badge">
                <GraduationCap size={16} />
                <span>{brand.subtitle}</span>
              </div>

              <div className="hero-text">
                <h1>Donner de la visibilité aux initiatives, aux idées et aux membres d&apos;Assas Connect.</h1>
                <p>{brand.tagline}</p>
              </div>

              <div className="hero-actions">
                <PrimaryButton href="#actualites">
                  <span className="inline-action">
                    Découvrir nos actualités
                    <ArrowRight size={16} />
                  </span>
                </PrimaryButton>
                <SecondaryButton href="#redaction">Lire nos articles</SecondaryButton>
              </div>

              <div className="highlight-grid">
                {highlights.map((item) => (
                  <div key={item} className="highlight-card">
                    <CheckCircle2 size={18} />
                    <p>{item}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}>
              <div className="showcase-card">
                <div className="showcase-toolbar">
                  <span />
                  <span />
                  <span />
                </div>
                <div className="showcase-content">
                  <div className="showcase-banner">
                    <p>Plateforme associative</p>
                    <h3>{brand.name}</h3>
                    <p>
                      Une page d&apos;accueil plus institutionnelle, inspirée du logo, pour mettre en avant la vie de l&apos;association,
                      les publications et l&apos;équipe.
                    </p>
                  </div>

                  <div className="showcase-grid">
                    {[
                      {
                        title: 'Actualités',
                        description: 'Mettre en avant vos projets, événements et annonces importantes.',
                        icon: Newspaper,
                      },
                      {
                        title: 'Rédaction',
                        description: 'Publier des articles, analyses, entretiens et contributions étudiantes.',
                        icon: PenSquare,
                      },
                      {
                        title: 'Membres',
                        description: "Présenter l'équipe de l'association de façon claire et élégante.",
                        icon: Users,
                      },
                    ].map((item) => {
                      const Icon = item.icon
                      return (
                        <div key={item.title} className="mini-card">
                          <div className="mini-icon">
                            <Icon size={18} />
                          </div>
                          <p className="mini-title">{item.title}</p>
                          <p className="mini-text">{item.description}</p>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section id="actualites" className="section-block">
          <div className="container split-section">
            <SectionTitle
              eyebrow="Actualités"
              title="Un espace pour raconter les projets et temps forts de l'association"
              description="Cette section peut accueillir vos annonces, projets en cours, événements, partenariats, appels à candidature ou récapitulatifs d'initiatives étudiantes."
            />

            <div className="card-grid three-cols">
              {newsItems.map((item, index) => (
                <motion.article key={item.title} {...fadeUp(index * 0.08)} className="info-card">
                  <div className="meta-badge">
                    <CalendarDays size={14} />
                    <span>{item.date}</span>
                  </div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <a href="#contact" className="inline-link">
                    Ajouter un contenu
                    <ArrowRight size={16} />
                  </a>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="redaction" className="section-block section-tinted">
          <div className="container">
            <SectionTitle
              eyebrow="Rédaction"
              title="Un espace éditorial pour publier vos articles"
              description="Pensé pour mettre en avant les contributions écrites de l'association : articles de fond, analyses, éditoriaux, interviews, comptes rendus et publications thématiques."
            />

            <div className="card-grid three-cols top-gap">
              {articles.map((item, index) => (
                <motion.article key={item.title} {...fadeUp(index * 0.08)} className="info-card">
                  <div className="meta-badge soft">{item.category}</div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <a href="#contact" className="inline-link">
                    Publier un article
                    <ArrowRight size={16} />
                  </a>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="membres" className="section-block">
          <div className="container">
            <SectionTitle
              eyebrow="Espace membre"
              title="Les membres d'Assas Connect"
              description="Cette section présente l'équipe de l'association sous forme de trombinoscope avec prénom, nom et poste. Des emplacements temporaires sont prévus pour que vous puissiez ajouter les vraies photos plus tard."
            />

            <div className="card-grid three-cols top-gap">
              {members.map((member, index) => (
                <motion.article key={`${member.role}-${index}`} {...fadeUp(index * 0.06)} className="member-card">
                  <div className="member-photo-placeholder">
                    <div className="member-initials">
                      {member.firstName.charAt(0)}
                      {member.lastName.charAt(0)}
                    </div>
                  </div>
                  <div className="member-content">
                    <div className="meta-badge soft">{member.role}</div>
                    <h3>
                      {member.firstName} {member.lastName}
                    </h3>
                    <p>Ajoutez ici la photo du membre plus tard, ainsi que ses informations définitives.</p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="section-block contact-section">
          <div className="container contact-grid">
            <div className="contact-copy">
              <p className="contact-kicker">Contact</p>
              <h2>Contacter Assas Connect</h2>
              <p>
                Utilise cette section pour permettre aux étudiants, partenaires ou futurs membres de prendre contact avec
                l&apos;association.
              </p>

              <div className="contact-list">
                <div>
                  <Mail size={16} />
                  <span>{brand.email}</span>
                </div>
                <div>
                  <MapPin size={16} />
                  <span>{brand.address}</span>
                </div>
              </div>
            </div>

            <div className="contact-card">
              <div className="form-grid">
                <label>
                  <span>Nom</span>
                  <input
                    value={form.name}
                    onChange={(event) => setForm((previous) => ({ ...previous, name: event.target.value }))}
                    placeholder="Votre nom"
                  />
                </label>

                <label>
                  <span>Email</span>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(event) => setForm((previous) => ({ ...previous, email: event.target.value }))}
                    placeholder="vous@exemple.fr"
                  />
                </label>

                <label>
                  <span>Message</span>
                  <textarea
                    value={form.message}
                    onChange={(event) => setForm((previous) => ({ ...previous, message: event.target.value }))}
                    placeholder="Votre message pour l'association"
                    rows="6"
                  />
                </label>

                <button type="button" className="button button-primary button-full">
                  Envoyer le message
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-row">
          <div>
            <p className="footer-title">© 2026 {brand.name}</p>
            <p>{brand.subtitle}</p>
          </div>
          <div className="footer-links">
            <a href="#actualites">Actualités</a>
            <a href="#redaction">Rédaction</a>
            <a href="#membres">Espace membre</a>
            <a href={`mailto:${brand.email}`}>Email</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
